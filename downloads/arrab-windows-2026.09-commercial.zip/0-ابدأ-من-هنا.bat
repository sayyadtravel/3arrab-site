@echo off
cd /d "%~dp0"
powershell -ExecutionPolicy Bypass -File "%~dp0deploy\windows\bootstrap-arrab.ps1" -BundleZip "%~dp0arrab-release.zip" -AutoInstallStack
echo.
pause
