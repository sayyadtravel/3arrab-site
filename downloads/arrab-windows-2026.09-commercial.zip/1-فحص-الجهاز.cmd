@echo off
cd /d "%~dp0"
powershell -ExecutionPolicy Bypass -File "%~dp0deploy\windows\preflight-arrab.ps1" -BundleZip "%~dp0arrab-release.zip" -InstallDir "C:\xampp\htdocs\arrab"
echo.
pause
