@echo off
cd /d "%~dp0"
powershell -ExecutionPolicy Bypass -File ".\install-arrab.ps1" -BundleZip "..\..\arrab-release.zip" -InstallDir "C:\Arrab"
echo.
pause
