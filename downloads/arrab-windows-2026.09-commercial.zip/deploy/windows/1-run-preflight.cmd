@echo off
cd /d "%~dp0"
powershell -ExecutionPolicy Bypass -File ".\preflight-arrab.ps1" -BundleZip "..\..\arrab-release.zip" -InstallDir "C:\Arrab"
echo.
pause
