@echo off
cd /d "%~dp0"
powershell -ExecutionPolicy Bypass -File ".\bootstrap-arrab.ps1" -AutoInstallStack
echo.
pause
