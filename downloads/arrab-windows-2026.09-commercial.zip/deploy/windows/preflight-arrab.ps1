param(
    [string]$BundleZip = "",
    [string]$InstallDir = "C:\Arrab",
    [string]$BundleMetaJson = ""
)

$ErrorActionPreference = "Stop"

function Check-Item {
    param(
        [string]$Name,
        [bool]$Ok,
        [string]$Detail
    )
    $status = if ($Ok) { "PASS" } else { "FAIL" }
    Write-Output "$status`t$Name`t$Detail"
}

function Read-ReleaseMeta {
    param([string]$ZipPath)
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $zip = [System.IO.Compression.ZipFile]::OpenRead($ZipPath)
    try {
        $entry = $zip.GetEntry("arrab-release.json")
        if (-not $entry) {
            return $null
        }
        $reader = New-Object System.IO.StreamReader($entry.Open())
        try {
            return ($reader.ReadToEnd() | ConvertFrom-Json)
        } finally {
            $reader.Dispose()
        }
    } finally {
        $zip.Dispose()
    }
}

$installDriveName = if ($InstallDir -match '^[A-Za-z]:') { $InstallDir.Substring(0,1) } else { (Get-Location).Path.Substring(0,1) }
$drive = Get-PSDrive -Name $installDriveName
$freeGb = [math]::Round($drive.Free / 1GB, 2)
Check-Item "PowerShell" ($PSVersionTable.PSVersion.Major -ge 5) $PSVersionTable.PSVersion.ToString()
Check-Item "DiskFreeGB" ($freeGb -ge 5) "$freeGb GB"
Check-Item "PHP" ([bool](Get-Command php -ErrorAction SilentlyContinue)) ((Get-Command php -ErrorAction SilentlyContinue).Source)
Check-Item "OpenSSL" ([bool](Get-Command openssl -ErrorAction SilentlyContinue)) ((Get-Command openssl -ErrorAction SilentlyContinue).Source)
Check-Item "MySQLClient" ([bool](Get-Command mysql -ErrorAction SilentlyContinue)) ((Get-Command mysql -ErrorAction SilentlyContinue).Source)

$apache = Get-Service -Name "Apache2.4" -ErrorAction SilentlyContinue
if (-not $apache) {
    $apache = Get-Service -Name "Apache24" -ErrorAction SilentlyContinue
}
Check-Item "ApacheService" ([bool]$apache) ($(if ($apache) { $apache.Status } else { "Not installed" }))

if ($BundleZip) {
    $bundleOk = Test-Path $BundleZip
    Check-Item "BundleZip" $bundleOk $(if ($bundleOk) { (Resolve-Path $BundleZip).Path } else { "Not found" })
    if ($bundleOk) {
        $bundlePath = (Resolve-Path $BundleZip).Path
        $bundleSize = (Get-Item $bundlePath).Length
        $needBytes = [Math]::Max(5GB, ($bundleSize * 2) + 512MB)
        $needGb = [math]::Round($needBytes / 1GB, 2)
        Check-Item "DiskFreeForBundle" ($drive.Free -ge $needBytes) ("need>={0} GB for install/extract" -f $needGb)

        $metaSidecar = $BundleMetaJson
        if (-not $metaSidecar) {
            $candidate = $bundlePath + ".meta.json"
            if (Test-Path $candidate) {
                $metaSidecar = $candidate
            }
        }
        if ($metaSidecar -and (Test-Path $metaSidecar)) {
            $metaPath = (Resolve-Path $metaSidecar).Path
            $sidecar = Get-Content $metaPath -Raw | ConvertFrom-Json
            $expected = [string]$sidecar.zip_sha256
            $actual = (Get-FileHash -Algorithm SHA256 -Path $bundlePath).Hash.ToLowerInvariant()
            Check-Item "BundleSHA256" ($expected -and $actual -eq $expected.ToLowerInvariant()) $(if ($expected) { $actual } else { "meta missing zip_sha256" })
        } else {
            Check-Item "BundleSHA256" $true "No sidecar provided"
        }

        $releaseMeta = Read-ReleaseMeta -ZipPath $bundlePath
        Check-Item "BundleReleaseMeta" ([bool]$releaseMeta) $(if ($releaseMeta) { [string]$releaseMeta.release } else { "arrab-release.json missing" })
        if ($releaseMeta) {
            $countOk = ([int]$releaseMeta.file_count -gt 0 -and [int]$releaseMeta.total_bytes -gt 0)
            Check-Item "BundleManifestCounts" $countOk ("files=" + [string]$releaseMeta.file_count + " bytes=" + [string]$releaseMeta.total_bytes)
        }
    }
} else {
    Check-Item "BundleZip" $true "Not provided"
}

$installExists = Test-Path $InstallDir
if (-not $installExists) {
    $parent = Split-Path -Parent $InstallDir
    Check-Item "InstallDirParent" ([bool]$parent -and (Test-Path $parent)) $(if ($parent) { $parent } else { "No parent path" })
} else {
    $children = @(Get-ChildItem -Force -Path $InstallDir)
    if ($children.Count -eq 0) {
        Check-Item "InstallDirState" $true "Empty"
    } elseif (Test-Path (Join-Path $InstallDir "arrab-release.json")) {
        Check-Item "InstallDirState" $true "Existing Arrab install"
    } else {
        Check-Item "InstallDirState" $false "Non-empty path without arrab-release.json"
    }
}

Write-Output "ARRAB_PREFLIGHT_DONE"
