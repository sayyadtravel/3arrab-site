param(
    [Parameter(Mandatory=$true)][string]$BundleZip,
    [Parameter(Mandatory=$true)][string]$InstallDir,
    [int]$CompanyId = 0,
    [string]$LicenseJson = "",
    [string]$LicenseSig = "",
    [string]$BundleMetaJson = "",
    [switch]$SkipHashCheck
)

$ErrorActionPreference = "Stop"

$BundleZip = (Resolve-Path $BundleZip).Path
if (!(Test-Path $BundleZip)) {
    throw "Bundle not found: $BundleZip"
}

$metaSidecar = $BundleMetaJson
if (-not $metaSidecar) {
    $candidate = $BundleZip + ".meta.json"
    if (Test-Path $candidate) {
        $metaSidecar = $candidate
    }
}
if ($metaSidecar) {
    $metaSidecar = (Resolve-Path $metaSidecar).Path
}

$bundleHash = (Get-FileHash -Algorithm SHA256 -Path $BundleZip).Hash.ToLowerInvariant()
$sidecar = $null
if ($metaSidecar -and (Test-Path $metaSidecar)) {
    $sidecar = Get-Content $metaSidecar -Raw | ConvertFrom-Json
    if (-not $SkipHashCheck -and $sidecar.zip_sha256) {
        $expected = [string]$sidecar.zip_sha256
        if ($bundleHash -ne $expected.ToLowerInvariant()) {
            throw "Bundle SHA256 mismatch: expected $expected got $bundleHash"
        }
    }
}

$stageDir = Join-Path ([System.IO.Path]::GetTempPath()) ("arrab-install-" + [guid]::NewGuid().ToString("N"))
New-Item -ItemType Directory -Force -Path $stageDir | Out-Null
try {
    Expand-Archive -Path $BundleZip -DestinationPath $stageDir -Force

    $metaFile = Join-Path $stageDir "arrab-release.json"
    if (!(Test-Path $metaFile)) {
        throw "Release metadata missing inside bundle: arrab-release.json"
    }
    $releaseMeta = Get-Content $metaFile -Raw | ConvertFrom-Json
    if (-not $releaseMeta.release) {
        throw "Release metadata invalid: missing release"
    }

    $required = @("index.php", "admin", "access", "includes")
    foreach ($name in $required) {
        if (!(Test-Path (Join-Path $stageDir $name))) {
            throw "Bundle missing required path: $name"
        }
    }

    New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null
    Copy-Item (Join-Path $stageDir "*") $InstallDir -Recurse -Force

    $companyRoot = Join-Path $InstallDir ("company\" + $CompanyId)
    $licenseRoot = Join-Path $companyRoot "license"
    $supportRoot = Join-Path $companyRoot "support"
    $backupRoot = Join-Path $companyRoot "backup"

    New-Item -ItemType Directory -Force -Path $companyRoot | Out-Null
    New-Item -ItemType Directory -Force -Path $licenseRoot | Out-Null
    New-Item -ItemType Directory -Force -Path $supportRoot | Out-Null
    New-Item -ItemType Directory -Force -Path $backupRoot | Out-Null

    if ($LicenseJson -and (Test-Path $LicenseJson)) {
        Copy-Item $LicenseJson (Join-Path $licenseRoot "active-license.json") -Force
    }
    if ($LicenseSig -and (Test-Path $LicenseSig)) {
        Copy-Item $LicenseSig (Join-Path $licenseRoot "active-license.sig") -Force
    }

    $receipt = [ordered]@{
        installed_at = (Get-Date).ToString("s")
        install_dir = $InstallDir
        company_id = $CompanyId
        bundle_zip = $BundleZip
        bundle_sha256 = $bundleHash
        bundle_meta_json = $metaSidecar
        hash_check_skipped = [bool]$SkipHashCheck
        license_json_installed = [bool]($LicenseJson -and (Test-Path $LicenseJson))
        license_sig_installed = [bool]($LicenseSig -and (Test-Path $LicenseSig))
        release = [ordered]@{
            release = [string]$releaseMeta.release
            channel = [string]$releaseMeta.channel
            version = [string]$releaseMeta.version
            generated_at = [string]$releaseMeta.generated_at
        }
        sidecar = if ($sidecar) { $sidecar } else { $null }
    }
    $receiptName = "install-receipt-" + (Get-Date -Format "yyyyMMdd-HHmmss") + ".json"
    $receiptPath = Join-Path $supportRoot $receiptName
    $receipt | ConvertTo-Json -Depth 6 | Set-Content -Encoding UTF8 $receiptPath

    Write-Host "Release metadata:"
    Get-Content $metaFile
    Write-Host "Install receipt:"
    Write-Host $receiptPath

    Write-Host "ARRAB_INSTALL_OK`t$InstallDir`t$receiptPath"
}
finally {
    if (Test-Path $stageDir) {
        Remove-Item $stageDir -Recurse -Force -ErrorAction SilentlyContinue
    }
}
