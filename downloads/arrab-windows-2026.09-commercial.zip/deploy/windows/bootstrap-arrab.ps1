param(
    [string]$BundleZip = "..\..\arrab-release.zip",
    [string]$InstallDir = "C:\xampp\htdocs\arrab",
    [string]$BundleMetaJson = "",
    [string]$CompanyName = "Arrab",
    [string]$AdminUser = "admin",
    [string]$AdminPassword = "Arrab123!",
    [string]$DbHost = "127.0.0.1",
    [string]$DbPort = "",
    [string]$DbName = "arrab",
    [string]$DbUser = "root",
    [string]$DbPassword = "",
    [string]$LanguageCode = "ar_EG",
    [switch]$AutoInstallStack
)

$ErrorActionPreference = "Stop"

function Write-Step($text) {
    Write-Host "[ARRAB] $text"
}

function Command-Exists($name) {
    return [bool](Get-Command $name -ErrorAction SilentlyContinue)
}

function Wait-TcpPort {
    param(
        [string]$Host,
        [int]$Port,
        [int]$TimeoutSec = 45
    )
    $deadline = (Get-Date).AddSeconds($TimeoutSec)
    while ((Get-Date) -lt $deadline) {
        try {
            $client = New-Object System.Net.Sockets.TcpClient
            $iar = $client.BeginConnect($Host, $Port, $null, $null)
            if ($iar.AsyncWaitHandle.WaitOne(1500, $false) -and $client.Connected) {
                $client.Close()
                return $true
            }
            $client.Close()
        } catch {
        }
        Start-Sleep -Seconds 2
    }
    return $false
}

function Ensure-Xampp {
    $xamppRoot = "C:\xampp"
    $phpExe = Join-Path $xamppRoot "php\php.exe"
    $apacheBat = Join-Path $xamppRoot "apache_start.bat"
    $mysqlBat = Join-Path $xamppRoot "mysql_start.bat"
    if ((Test-Path $phpExe) -and (Test-Path $apacheBat) -and (Test-Path $mysqlBat)) {
        return $xamppRoot
    }
    if (-not $AutoInstallStack) {
        throw "XAMPP is missing. Re-run with AutoInstallStack or install C:\\xampp first."
    }
    if (-not (Command-Exists "winget")) {
        throw "winget is missing and XAMPP cannot be installed automatically."
    }
    Write-Step "Installing XAMPP via winget..."
    & winget install --id ApacheFriends.Xampp.8.2 --exact --silent --accept-package-agreements --accept-source-agreements
    if ($LASTEXITCODE -ne 0) {
        throw "XAMPP automatic install failed via winget."
    }
    if (-not (Test-Path $phpExe)) {
        throw "XAMPP install completed but C:\\xampp\\php\\php.exe was not found."
    }
    return $xamppRoot
}

function Start-XamppStack {
    param([string]$XamppRoot)
    $mysqlBat = Join-Path $XamppRoot "mysql_start.bat"
    $apacheBat = Join-Path $XamppRoot "apache_start.bat"
    if (-not (Wait-TcpPort -Host "127.0.0.1" -Port 3306 -TimeoutSec 2)) {
        Write-Step "Starting MySQL..."
        Start-Process -FilePath $mysqlBat -WorkingDirectory $XamppRoot -WindowStyle Hidden
        if (-not (Wait-TcpPort -Host "127.0.0.1" -Port 3306 -TimeoutSec 45)) {
            throw "Local MySQL did not start on port 3306."
        }
    }
    if (-not (Wait-TcpPort -Host "127.0.0.1" -Port 80 -TimeoutSec 2)) {
        Write-Step "Starting Apache..."
        Start-Process -FilePath $apacheBat -WorkingDirectory $XamppRoot -WindowStyle Hidden
        if (-not (Wait-TcpPort -Host "127.0.0.1" -Port 80 -TimeoutSec 45)) {
            throw "Local Apache did not start on port 80."
        }
    }
}

function Write-DesktopShortcut {
    param(
        [string]$Name,
        [string]$Url
    )
    $desktop = [Environment]::GetFolderPath("Desktop")
    $file = Join-Path $desktop ($Name + ".url")
    @"
[InternetShortcut]
URL=$Url
"@ | Set-Content -Encoding ASCII $file
    return $file
}

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$bundlePath = Join-Path $scriptDir $BundleZip
if (-not (Test-Path $bundlePath)) {
    throw "Bundle not found: $bundlePath"
}

Write-Step "Ensuring local stack..."
$xamppRoot = Ensure-Xampp
Start-XamppStack -XamppRoot $xamppRoot

Write-Step "Installing Arrab files..."
$installArgs = @(
    "-ExecutionPolicy", "Bypass",
    "-File", (Join-Path $scriptDir "install-arrab.ps1"),
    "-BundleZip", $bundlePath,
    "-InstallDir", $InstallDir
)
if ($BundleMetaJson -ne "") {
    $installArgs += @("-BundleMetaJson", (Join-Path $scriptDir $BundleMetaJson))
}
& powershell @installArgs
if ($LASTEXITCODE -ne 0) {
    throw "install-arrab.ps1 failed."
}

$phpExe = Join-Path $xamppRoot "php\php.exe"
$headless = Join-Path $InstallDir "scripts\arrab_install_headless.php"
if (-not (Test-Path $headless)) {
    throw "Headless installer missing: $headless"
}

Write-Step "Initializing database and config..."
& $phpExe $headless `
    "--db-host=$DbHost" `
    "--db-port=$DbPort" `
    "--db-name=$DbName" `
    "--db-user=$DbUser" `
    "--db-password=$DbPassword" `
    "--company-name=$CompanyName" `
    "--admin-user=$AdminUser" `
    "--admin-password=$AdminPassword" `
    "--lang=$LanguageCode"
if ($LASTEXITCODE -ne 0) {
    throw "arrab_install_headless.php failed."
}

$url = "http://localhost/arrab"
$shortcut = Write-DesktopShortcut -Name "Arrab" -Url $url

$receipt = [ordered]@{
    installed_at = (Get-Date).ToString("s")
    bundle_zip = $bundlePath
    install_dir = $InstallDir
    app_url = $url
    desktop_shortcut = $shortcut
    xampp_root = $xamppRoot
    db_name = $DbName
    admin_user = $AdminUser
}
$receiptPath = Join-Path $InstallDir "bootstrap-install-receipt.json"
$receipt | ConvertTo-Json -Depth 4 | Set-Content -Encoding UTF8 $receiptPath

Write-Step "Open Arrab at: $url"
Write-Step "Desktop shortcut: $shortcut"
Write-Host "ARRAB_BOOTSTRAP_OK`t$InstallDir`t$url"
