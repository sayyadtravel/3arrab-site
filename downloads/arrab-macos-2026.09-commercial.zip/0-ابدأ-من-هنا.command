#!/bin/sh
set -eu
SCRIPT_DIR="$(CDPATH= cd -- "$(dirname "$0")" && pwd)"
sh "$SCRIPT_DIR/deploy/macos/bootstrap-arrab.command"
