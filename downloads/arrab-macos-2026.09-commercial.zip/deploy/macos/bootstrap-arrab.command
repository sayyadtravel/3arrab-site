#!/bin/sh
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname "$0")" && pwd)"
BUNDLE_ZIP="$SCRIPT_DIR/../../arrab-release.zip"
INSTALL_DIR="$HOME/Applications/Arrab"
HTTP_PORT="${ARRAB_HTTP_PORT:-8080}"

sh "$SCRIPT_DIR/install-arrab.sh" \
  "--bundle-zip=$BUNDLE_ZIP" \
  "--install-dir=$INSTALL_DIR" \
  "--http-port=$HTTP_PORT"

echo
echo "ARRAB_MAC_BOOTSTRAP_OK	$INSTALL_DIR	http://127.0.0.1:${HTTP_PORT}"
