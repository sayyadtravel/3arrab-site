#!/bin/sh
set -eu
SCRIPT_DIR="$(CDPATH= cd -- "$(dirname "$0")" && pwd)"
sh "$SCRIPT_DIR/preflight-arrab.sh" \
  "--bundle-zip=$SCRIPT_DIR/../../arrab-release.zip" \
  "--install-dir=$HOME/Applications/Arrab"
